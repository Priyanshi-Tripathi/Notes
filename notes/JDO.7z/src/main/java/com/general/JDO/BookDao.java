package com.general.JDO;

public interface BookDao {
	
	public void insert(Book b);

}
